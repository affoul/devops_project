package com.example.hiarflow.model;

public class Admin {
}
